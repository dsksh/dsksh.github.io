# Artifacts for the VMCAI'21 Paper

Daisuke Ishii (`dsksh@jaist.ac.jp`)

## Objectives

- Provide example descriptions of synchronous systems (in Simulink and Lustre).
- Demonstrate that some processes of the proposed method can be automated.
    - Mainly, Step 2 of the method for test generation and Step 3 for consistency checking.
- Provide a computer-assisted proof of (the most part of) compositional reasoning made by the proposed method.


## Used Tools

- [Kind2](https://kind2-mc.github.io/kind2/) 1.2.0
- [Z3](https://github.com/Z3Prover/z3) 4.8.8
- [MATLAB/Simulink](https://www.mathworks.com/products/simulink.html) R2018b and R2019b


## Tested Environments

- Machine 1
    - OS: Ubuntu 20.04
    - CPU: 2.2GHz Intel Xeon E5-2650v4
    - RAM: 128GB
- Machine 2
    - OS: macOS Mojave 10.14.6
    - CPU: 2.3GHz Intel Core i5
    - RAM: 16GB
- [VMCAI 2021 Virtual Machine](https://zenodo.org/record/4017293#.X4e7hi8RrHV)
    - OS: Ubuntu 20.04 with Linux 5.4.0-45 
    - VirtualBox 6.1.10 (executen on Machine 1)
    - RAM: 8GB


## Directory Structure and Content

```
+-- local/
|   |
|   +-- bin/
|   |   +-- kind2: Kind2 executable.
|   |   +-- z3: Z3 executable.
|   |
|   +-- src/
|       +-- kind2-1.2.0.tar.gz: Source code of Kind2.
|       +-- z3-Z3-4.8.8.tar.gz: Source code of Z3.
|
+-- vmcai2021ae/
    +-- S1/: Contains files related to System 1.
    |   +-- *.lus: Lustre file for Kind2.
    |   +-- *.smt2: SMT-LIB file for Z3.
    |   +-- *.slx: Simulink model.
    |   (Same kinds of files are contained in the following sub-directories.)
    |
    +-- S2/: System 2.
    +-- S3/: System 3.
    +-- S4/: System 4.
    |
    +-- logs_on_m1/: Contains the logs taken on Machine 1.
    +-- logs_on_vm/: Contains the logs taken on the VM.
    |
    +-- README.md: This file.
```


## Quick Usage Instructions

This section explains how to execute validation processes using Kind2 and Z3 on the VMCAI 2021 Virtual Machine.

0. We assume the current directory is `/home/vmcai2021/`.
   ```
   $ pwd
   /home/vmcai2021
   ```
1. Set up the artifact.
   ```
   $ wget https://dsksh.github.io/vmcai2021ae.zip
   ...
   $ unzip vmcai2021ae.zip
   ```
   Then, configure the path to executables.
   ```
   $ export PATH=$HOME/local/bin:$PATH
   ```
2. Here, we assume that the target is Sys. 1 (`FilterCounter`). 
   Execute Kind2 for test generation and validation of the proof tree nodes as follows.
   ```
   $ cd vmcai2021ae/S1
   $ kind2 --compositional false --modular true FilterCounter_v.lus
   ...
   ```
   How to interpret the output is explained below. 
3. Then, execute Z3 for validation of the proof tree nodes.
   ```
   $ z3 -smt2 FilterCounter_comp.smt2
   ...
   ```
   How to interpret the output is explained below. 
4. Processing for other examples is likewise.
   - I.e. to repeat Steps 2-3 for sub-directories `S2`, `S3` and `S4`.
   - **[Remark]** Step 2 above for Sys. 3 (`PMMotorFront_v.lus`) will take several hours on the VM. It is recommended to validate each goal separately (by commenting out the other goals).
        - Use `PMMotorFront_v_p1.lus` instead of `PMMotorFront_v.lus` to validate a subset of the goals.


## What is Computed?

The processes executed above are checking the correctness of the proof trees, generated with the proposed scheme (such as Fig. 3 and Fig. 5 in the paper).
See also the example below.

<br />

Process using Kind2 addresses the leaves of the trees.
A claim of an implementation relation at a leaf is described as follows.
The target synchronous nodes are described as Lustre nodes.
The properties in the claim are annotated in a node description with the CoCoSpec language.

Then the properties described with `PROPERTY` and `guarantee` constructs are either falsified or validated.
Falsification aims to generate a (portion of) test case as a counterexample.
A success of falsification outputs `invalid` and a counterexample trace. 
It also means that there exists a test case that satisfies the claim.
Validation aims to prove the correctness of a claim.
As a result, `valid` should be output.

<br />

Process using Z3 formalizes inferences made in the proof trees.
At the top of each SMT-LIB file, the inference rules in Fig. 2 of the paper are defined.
Then, we define the leaf claims in the tree, and describe commands for proving the parent claims.
Each parent claim is proved by checking the unsatisfiability of its negation, so output `unsat` means success of a proof.


## Example Synchronous Systems

### System 1: A filter and a counter

System model w/ a test harness (made w/ R2018b):

- `FilterAndCounter_harness.slx`

System models in Lustre w/ annotations for test generation/validation:

- `FilterCounter.lus` (for monolithic test generation)
- `FilterCounter_v.lus` (for falsification and validation of leaf claims)
- `FilterCounter_tg.lus` (contains only falsification goals)

SMT-LIB script for validation of the compositional reasoning:

- `Filtercounter_comp.smt2`


### System 2: Two guarded decrementers

System model w/ a test harness (made w/ R2018b):

- `TwoGuardedCounters_harness.slx`

System models in Lustre w/ annotations for test generation/validation:

- `TwoGuardedDecrimenters.lus` (for monolithic test generation)
- `TwoGuardedDecrimenters_v.lus` (for falsification and validation of leaf claims)
- `TwoGuardedDecrimenters_combi_tg.lus` (contains only falsification goals)

SMT-LIB script for validation of the compositional reasoning:

- `Twoguardeddecrimenters_comp.smt2`


### System 3: PM motor control

Simulink model is not included, as it is confidential.

System models in Lustre w/ annotations for test generation/validation:

- `PMMotorFront.lus` (for monolithic test generation)
- `PMMotorFront_v.lus` (for falsification and validation of leaf claims)
- `PMMotorFront_combi_tg.lus` (contains only falsification goals)

SMT-LIB scripts for validation of the compositional reasoning:

- `PMMotorFront_comp.smt2`
- `PMMotorFront_ssX20.smt2` (for Temp compositions on ssX20)


### System 4: Extended two guarded decrementers (Sample1)

Simulink model is not included, as it is confidential.

System models in Lustre w/ annotations for test generation/validation:

- `Sample1.lus` (for monolithic test generation)
- `Sample1_v.lus` (for falsification and validation of leaf claims)
- `Sample1_combi_tg.lus` (contains only falsification goals)

SMT-LIB scripts for validation of the compositional reasoning:

- `Sample1_comp.smt2`
- `Sample1_top.smt2` (for the top-level Temp compositions)


## Basic Commands

Lustre file contains only goals to be falsified can be processed as:
```
$ kind2 --enable BMC --compositional false --modular true FilterCounter_tg.lus
```
Kind2 will apply only BMC to the goals.

Either of falsification or validation goals can be processed as:
```
$ kind2 --compositional false --modular true FilterCounter_v.lus
```
Kind2 applies several methods to each goal in parallel.

SMT-LIB scripts are processed as:
```
$ z3 -smt2 FilterCounter_comp.smt2
```


## Example: Proof Tasks for System 1

We explain how the proof tree for System 1 is processed using the tools.

![](S1/FilterCounter_prooftree.png)

In the proof tree above, leaves are Equations (1), (2) and (5).

For example, in (2), the target node is `Counter` (Lines 90-98 of `Filtercounter_v.lus`).
At Lines 100-113, a harness node `hCounter_RT1_Step` is described as follows.
```
node hCounter_RT1_Step (c: int; En: bool)
returns (COut: bool)
(*@contract
  assume c = (0 -> 1 + pre c);
  assume (c = 1 => En) and (c = 2 => En);

  --
  -- Validation of Eq (2).
  --
  guarantee c = 2 => COut; -- valid (at 11) by 2-induction
*)
let
  COut = Counter(RateTransition(En, 1));
tel
```
It is annotated with the properties.
In the `@contract` section, the second assumption specifies the property in the left-hand side.
The property in the right-hand side is specified with `guarantee`.
The assume-guarantee relation for this node is checked via validation of the `guarantee` property using Kind2.

The claim (1) is described likewise at Lines 43-86.
The negation of the right-hand side property is specified with the `PROPERTY` construct at Line 82.
```
  --
  -- Falsification of Eq (1) for TC generation.
  --
  --%PROPERTY not (c = 20 and d10 and FOut); -- invalid after 20 steps by BMC
```
Processing this command with Kind2 will output a counterexample.

<br />

The inferences in the tree are validated in `FilterCounter_comp.smt2`.
Claims are described in a simplified way using the vocabularies prepared at Lines 5-36.
The inference rules are defined at Lines 38-66. E.g.:
```
;; R_AG
(assert
  (forall ((n1 snode) (n2 snode) (na snode) (nb snode))
    (=> (and (impl (PC n1 nb) na) (impl (PC n2 na) nb)) 
      (impl (PC n1 n2) (PC na nb)) )))
```

The claims (1) and (2) are introduced as axioms at Lines 104 and 109.
E.g., (1) is specified as:
```
;;
;; Axiom Eq (1).
;;
(assert (impl (PC (PC (N 0) (N 1)) (P 1 20)) (P 0 20)))
```

Then, we try to prove the claim (3) at Lines 114-125.
```
;;
;; Validation of Eq (3).
;;
(declare-const e3 Bool)
(assert (= e3
           (impl (PC (PC (N 0) (N 1))  (RT 10 (N 2))) 
                 (PC (P 0 20) (P 1 20)) )))

(push 1)
(assert (not e3))
(check-sat)
(pop 1)
```

The other parent claims are proved in a similar way.


## Execution Time

Execution time for processing each file on the VM was as follows:

- `FilterCounter_v.lus`: 15s
- `FilterCounter_tg.lus`: 2.9s
- `FilterCounter_comp.smt2`: 0.03s
- `TwoGuardedDecrimenters_v.lus`: 120s
- `TwoGuardedDecrimenters_combi_tg.lus`: 12s
- `TwoGuardedDecrimenters_comp.smt2`: 0.09s
- `PMMotorFront_v.lus`: several hours
- `PMMotorFront_v_p1.lus`: 730s
- `PMMotorFront_combi_tg.lus`: 570s
- `PMMotorFront_comp.smt2`: 0.43s
- `Sample1_v.lus`: 2600s
- `Sample1_combi_tg.lus`: 390s
- `Sample1_comp.smt2`: 14s


## Remarks

- Validation with Kind2 for Sys. 3 (`PMMotorFront_v.lus`) and Sys. 4 (`Sample1_v.lus`) takes a long time on the VM.
    - Each of them terminates within an hour on Machine 1.
- Kind2 will be more efficient when goals are fed separately.
    - Commenting out some goals improves the execution time of a process drastically.
    - Commenting out examples:
        - `guarantee ...` --> `--guarantee ...`
        - `--%PROPERTY ...` --> `-- PROPERTY ...`
- A validation process of Kind2 rarely does not terminate, probably due to a deadlock in parallel computation.
- Description of the dummy nodes at the end of every Lustre files is kludgy. It is used only for invoking sub-tasks and it does not affect the sub-tasks.


## License

This artifact is released under the MIT License, see LICENSE.txt.

Kind 2 is distributed under the Apache license (V2).

Z3 is distributed under the MIT license.

<!-- EOF -->

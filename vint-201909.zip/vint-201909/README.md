# vint

`vint` is an interval arithmetic library verified by [Why3](http://why3.lri.fr).

## Verification tools

* Why3 1.1.0
* Alt-Ergo 2.2.0
* Z3 4.7.1
* Coq 8.8.2

## How to verify

```sh
why3 ide -L ./src ./src/add.mlw
```

## OCaml code extraction

### Requirements

* GNU make
* OCaml (>= 4.02.3)
* [Why3](http://why3.lri.fr) (>= 1.1.0)
* [dune](https://github.com/ocaml/dune) (>= 1.2)

### Installation

```sh
# Install dependency
$ opam pin add -y round git@github.com:tyabu12/ocaml-round.git
# Build
$ make
# Run examples
$ make run-examples
# Install
$ make install
```

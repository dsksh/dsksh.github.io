type interval = {
  inf: float;
  sup: float;
  }

let zeroI  : interval = { inf = 0.; sup = 0. }

let add (x: interval) (y: interval) : interval =
  let r =
    { inf = (Round.add Round.Down (x.inf) (y.inf)); sup =
      (Round.add Round.Up   (x.sup) (y.sup)) } in
  r

let sub (x: interval) (y: interval) : interval =
  let r =
    { inf = (Round.sub Round.Down (x.inf) (y.sup)); sup =
      (Round.sub Round.Up   (x.sup) (y.inf)) } in
  r

let mul (x: interval) (y: interval) : interval =
  let r =
    if (x.inf) >= 0. then begin
      if (x.sup) =  0. then begin zeroI end
      else
      begin
        if (y.inf) >= 0. then begin
          if (y.sup) =  0. then begin zeroI end
          else
          begin
            { inf = (Round.mul Round.Down (x.inf) (y.inf)); sup =
              (Round.mul Round.Up   (x.sup) (y.sup)) } end end
        else
        begin
          if (y.sup) <= 0. then begin
            { inf = (Round.mul Round.Down (x.sup) (y.inf)); sup =
              (Round.mul Round.Up   (x.inf) (y.sup)) } end
          else
          begin
            { inf = (Round.mul Round.Down (x.sup) (y.inf)); sup =
              (Round.mul Round.Up   (x.sup) (y.sup)) } end end end end
    else
    begin
      if (x.sup) <= 0. then begin
        if (y.inf) >= 0. then begin
          if (y.sup) =  0. then begin zeroI end
          else
          begin
            { inf = (Round.mul Round.Down (x.inf) (y.sup)); sup =
              (Round.mul Round.Up   (x.sup) (y.inf)) } end end
        else
        begin
          if (y.sup) <= 0. then begin
            { inf = (Round.mul Round.Down (x.sup) (y.sup)); sup =
              (Round.mul Round.Up   (x.inf) (y.inf)) } end
          else
          begin
            { inf = (Round.mul Round.Down (x.inf) (y.sup)); sup =
              (Round.mul Round.Up   (x.inf) (y.inf)) } end end end
      else
      begin
        if (y.inf) >= 0. then begin
          if (y.sup) =  0. then begin zeroI end
          else
          begin
            { inf = (Round.mul Round.Down (x.inf) (y.sup)); sup =
              (Round.mul Round.Up   (x.sup) (y.sup)) } end end
        else
        begin
          if (y.sup) <= 0. then begin
            { inf = (Round.mul Round.Down (x.sup) (y.inf)); sup =
              (Round.mul Round.Up   (x.inf) (y.inf)) } end
          else
          begin
            let inf1 = Round.mul Round.Down (x.inf) (y.sup) in
            let inf2 = Round.mul Round.Down (x.sup) (y.inf) in
            let sup1 = Round.mul Round.Up   (x.inf) (y.inf) in
            let sup2 = Round.mul Round.Up   (x.sup) (y.sup) in
            { inf =
              (if inf1 <  inf2 then begin inf1 end else begin inf2 end);
              sup =
              (if sup1 >  sup2 then begin sup1 end else begin sup2 end) } end end end end in
  r

exception Division_by_zero

let div (x: interval) (y: interval) : interval =
  let r =
    if (y.inf) >  0. then begin
      if (x.inf) >= 0. then begin
        { inf = (Round.div Round.Down (x.inf) (y.sup)); sup =
          (Round.div Round.Up   (x.sup) (y.inf)) } end
      else
      begin
        if (x.sup) <= 0. then begin
          { inf = (Round.div Round.Down (x.inf) (y.inf)); sup =
            (Round.div Round.Up   (x.sup) (y.sup)) } end
        else
        begin
          { inf = (Round.div Round.Down (x.inf) (y.inf)); sup =
            (Round.div Round.Up   (x.sup) (y.inf)) } end end end
    else
    begin
      if (y.sup) <  0. then begin
        if (x.inf) >= 0. then begin
          { inf = (Round.div Round.Down (x.sup) (y.sup)); sup =
            (Round.div Round.Up   (x.inf) (y.inf)) } end
        else
        begin
          if (x.sup) <= 0. then begin
            { inf = (Round.div Round.Down (x.sup) (y.inf)); sup =
              (Round.div Round.Up   (x.inf) (y.sup)) } end
          else
          begin
            { inf = (Round.div Round.Down (x.sup) (y.sup)); sup =
              (Round.div Round.Up   (x.inf) (y.sup)) } end end end
      else
      begin
        raise Division_by_zero end end in
  r


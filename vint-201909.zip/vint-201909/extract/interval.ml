type interval = {
  inf: float;
  sup: float;
  }

let zeroI  : interval = { inf = 0.; sup = 0. }


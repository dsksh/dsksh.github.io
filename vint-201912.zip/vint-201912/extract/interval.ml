type interval = {
  inf: float;
  sup: float;
  }


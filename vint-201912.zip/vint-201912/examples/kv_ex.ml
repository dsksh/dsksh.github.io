open Printf
open Vint.Kv

let string_of_float = sprintf "%.16e"
let string_of_interval x =
  sprintf "[%s,%s]" (string_of_float x.inf) (string_of_float x.sup)

let println_bool x = print_endline (string_of_bool x)
let println_float x = print_endline (string_of_float x)
let println_interval x = print_endline (string_of_interval x)

let make u v = {inf=u; sup=v}

let () =
  let x = make 1. 2. in
  let y = make 3. 4. in

  (* basic four operations *)
  printf "%s + %s = %s\n"
    (string_of_interval x)
    (string_of_interval y)
    (string_of_interval (add x y));
  printf "%s - %s = %s\n"
    (string_of_interval x)
    (string_of_interval y)
    (string_of_interval (sub x y));
  printf "%s * %s = %s\n"
    (string_of_interval x)
    (string_of_interval y)
    (string_of_interval (mul x y));
  printf "%s / %s = %s\n"
    (string_of_interval x)
    (string_of_interval y)
    (string_of_interval (div x y));
  ()

# Supplementary materials for the VMCAI'21 paper

Daisuke Ishii (`dsksh@jaist.ac.jp`)

## Used Tools

- [Kind2](https://kind2-mc.github.io/kind2/) 1.2.0
- [Z3](https://github.com/Z3Prover/z3) 4.8.8
- [MATLAB/Simulink](https://www.mathworks.com/products/simulink.html) R2018b and R2019b


## Usage Example

Test generation by a falsification can be run as
```
$ kind2 --enable BMC --compositional true TwoGuardedDecrimenters_combi_trials.lus
```

Validation of the composition and the test case can be run as
```
$ z3 -smt2 TwoGuardedDecrimenters_comp.smt2
```


[Optional] Validation of the composition and the test case can be run as
```
$ kind2 --compositional true --modular true TwoGuardedDecrimenters_combi_comp.lus
```
The validation done with this process is partial and should be covered by the above process using Z3.


## Files

### System 1: A filter and a counter

System model w/ a test harness (made w/ R2018b):

- `FilterAndCounter_harness.slx`

System models in Lustre w/ annotations for test generation/validation:

- `FilterCounter.lus` (for monolithic test generation)
- `FilterCounter_trials.lus` (for compositional test generation)
- `FilterCounter_comp.lus` (for validation of compositional test case)

SMT-LIB script for validation of the compositional reasoning:

- `Filtercounter_comp.smt`


### System 2: Two guarded decrementers

System model w/ a test harness (made w/ R2018b):

- `TwoGuardedCounters_harness.slx`

System models in Lustre w/ annotations for test generation/validation:

- `TwoGuardedDecrimenters.lus` (for monolithic test generation)
- `TwoGuardedDecrimenters_combi_comp.lus` (for compositional test generation)
- `TwoGuardedDecrimenters_combi_trials.lus` (for validation of compositional test case)

SMT-LIB script for validation of the compositional reasoning:

- `Twoguardeddecrimenters_comp.smt2`


### System 3: PM motor control

Simulink model is not included, as it is confidential.

System models in Lustre w/ annotations for test generation/validation:

- `PMMotorFront.lus` (for monolithic test generation)
- `PMMotorFront_combi_comp.lus` (for compositional test generation)
- `PMMotorFront_combi_trials.lus` (for validation of compositional test case)

SMT-LIB scripts for validation of the compositional reasoning:

- `PMMotorFront_comp.smt2`
- `PMMotorFront_ssX20.smt2` (for Temp compositions on ssX20)


### System 4: Extended two guarded decrementers (Sample1)

Simulink model is not included, as it is confidential.

System models in Lustre w/ annotations for test generation/validation:

- `Sample1.lus` (for monolithic test generation)
- `Sample1_combi_comp.lus` (for compositional test generation)
- `Sample1_combi_trials.lus` (for validation of compositional test case)

SMT-LIB scripts for validation of the compositional reasoning:

- `Sample1_comp.smt2`
- `Sample1_top.smt2` (for the top-level Temp compositions)

<!-- EOF -->

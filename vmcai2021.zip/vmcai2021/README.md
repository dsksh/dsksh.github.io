# Supplementary materials for the VMCAI'21 paper

Daisuke Ishii (`dsksh@jaist.ac.jp`)

## Used Tools

- [Kind2](https://kind2-mc.github.io/kind2/) 1.2.0
- [Z3](https://github.com/Z3Prover/z3) 4.8.8
- [MATLAB/Simulink](https://www.mathworks.com/products/simulink.html) R2018b and R2019b

## Usage Example

Test generation by a falsification can be run as
```
$ kind2 --enable BMC --compositional true TwoGuardedDecrimenters_combi_trials.lus
```

Validation of the composition and the test case can be run as
```
$ kind2 --compositional true --modular true TwoGuardedDecrimenters_combi_comp.lus
```

## Files

### System 1: A filter and a counter

System model w/ a test harness (made w/ R2018b):

- `FilterAndCounter_harness.slx`

System models in Lustre w/ annotations for test generation/validation:

- `FilterCounter.lus` (for monolithic test generation)
- `FilterCounter_trials.lus` (for compositional test generation)
- `FilterCounter_comp.lus` (for validation of compositional test case)

### System 2: Two guarded decrementers

System model w/ a test harness (made w/ R2018b):

- `TwoGuardedCounters_harness.slx`

System models in Lustre w/ annotations for test generation/validation:

- `TwoGuardedDecrimenters.lus` (for monolithic test generation)
- `TwoGuardedDecrimenters_combi_comp.lus` (for compositional test generation)
- `TwoGuardedDecrimenters_combi_trials.lus` (for validation of compositional test case)

<!-- EOF -->
